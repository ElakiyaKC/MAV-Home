package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class ManageTenantActivity extends AppCompatActivity {
    Button logoutbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_tenant);

        ListView list = (ListView) findViewById(R.id.manage_tenant_list);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case 0:  Intent newActivity = new Intent(ManageTenantActivity.this, AddTenantActivity.class);
                        startActivity(newActivity);
                        break;
                    case 1:
                        Runnable r = new Runnable() {
                            @Override
                            public void run(){
                                Toast toast=Toast.makeText(getApplicationContext(),"The tenant has been removed successfully", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                toast.show();
                            }
                        };

                        Handler h = new Handler();
                        h.postDelayed(r, 1000);

                        break;
                }
            }
        });
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(ManageTenantActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});
    }
}
