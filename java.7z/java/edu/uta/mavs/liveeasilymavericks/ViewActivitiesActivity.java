package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class ViewActivitiesActivity extends AppCompatActivity {
    Button logoutbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_activities);
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Runnable r = new Runnable() {
                    @Override
                    public void run(){
                        Intent newActivity = new Intent(ViewActivitiesActivity.this, LoginActivity.class);
                        startActivity(newActivity);
                    }
                };
                Handler h = new Handler();
                h.postDelayed(r, 1000);
            }});
    }
}
