package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

public class ApartmentActivity extends AppCompatActivity {
    Button logoutbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apartment);

        ListView list = (ListView) findViewById(R.id.apartment_options);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case 0:  Intent newActivity = new Intent(ApartmentActivity.this, ManageTenantActivity.class);
                        startActivity(newActivity);
                        break;
                    case 1:  Intent newActivity1 = new Intent(ApartmentActivity.this, ManageInspectionActivity.class);
                        startActivity(newActivity1);
                        break;
                }
            }
        });
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(ApartmentActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});
    }
}
