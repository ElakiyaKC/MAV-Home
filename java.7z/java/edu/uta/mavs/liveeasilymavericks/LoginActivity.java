

        package edu.uta.mavs.liveeasilymavericks;

        import android.content.Intent;
        import android.os.AsyncTask;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Toast;

        import java.sql.DriverManager;
        import java.sql.ResultSet;
        import java.sql.Statement;
public class LoginActivity extends AppCompatActivity {
    private static final String url = "#####";
    private static final String username = "#####";
    private static final String password = "#####";
    Button loginbtn;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        final EditText inputusername = (EditText) findViewById(R.id.username_et);
        final EditText inputpassword = (EditText) findViewById(R.id.password_et);
        loginbtn = (Button) findViewById(R.id.login_btn);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MyTask mytask = new MyTask();
                mytask.execute(new String[]{inputusername.getText().toString(),inputpassword.getText().toString()});

            }

        });

    }

    private class MyTask extends AsyncTask<String, Void, Void> {
        private static final String url = "#####";
        private static final String username = "#####";
        private static final String password = "#####";
        @Override
        protected Void doInBackground(String... params) {
            String user="";
            String pw="";
            try {
                final String inputusername = params[0];
                final String inputpassword = params[1];
                Class.forName("com.mysql.jdbc.Driver");
                java.sql.Connection conn = DriverManager.getConnection(url,username,password);
                Statement st = conn.createStatement();
                String sql = "select * from users where username='"+inputusername+"' and password='"+inputpassword+"'";
                //System.out.println(sql);
                final ResultSet rs = st.executeQuery(sql);
                if(!rs.next()){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run () {
                            Toast failure = Toast.makeText(getApplicationContext(), "The username/password entered is incorrect", Toast.LENGTH_SHORT);
                            failure.show();
                        }
                    });
                }
                //rs.next();
                user=rs.getString("username");
                pw=rs.getString("password");

                if(user.charAt(0)=='m')
                    {
                        Intent intent = new Intent(LoginActivity.this, ManagerHomeActivity.class);
                        startActivity(intent);
                        Toast toast1 = Toast.makeText(getApplicationContext(),"login successful",Toast.LENGTH_SHORT);
                        toast1.show();

                    }
                else if(user.charAt(0) == 't') {
                    Intent intent = new Intent(LoginActivity.this, TenantHomeActivity.class);
                    startActivity(intent);
                    Toast toast2 = Toast.makeText(getApplicationContext(),"login successful",Toast.LENGTH_SHORT);
                    toast2.show();
                }

                else
                {
                    Toast toast3 = Toast.makeText(getApplicationContext(),"Either username or password is incorrect",Toast.LENGTH_SHORT);
                    toast3.show();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

            super.onPostExecute(aVoid);
        }
    }
}
