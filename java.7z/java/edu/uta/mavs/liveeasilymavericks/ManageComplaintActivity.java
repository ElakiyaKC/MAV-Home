package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Toast;

public class ManageComplaintActivity extends AppCompatActivity {
    Button logoutbtn;
    Button savebtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_complaint);
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(ManageComplaintActivity.this, LoginActivity.class);
                startActivity(newActivity);

            }});
        savebtn=(Button)findViewById(R.id.save_button);
        savebtn.setOnClickListener(new View.OnClickListener()
        {public void onClick(View view){
            Runnable r = new Runnable() {
                @Override
                public void run(){
                    Toast toast = Toast.makeText(getApplicationContext(),"The complaint has been updated",Toast.LENGTH_SHORT);
                    toast.show();
                    Intent newActivity = new Intent(ManageComplaintActivity.this, ViewComplaintActivity2.class);
                    startActivity(newActivity);
                }
            };
            Handler h = new Handler();
            h.postDelayed(r, 1000);
        }

    });}
    public String onRadioButtonClicked(View view) {
        // Is the button now checked?
        String type="";

        boolean checked = ((RadioButton) view).isChecked();

        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.resolve:
                if (checked)
                    type = "Resolved";
                break;
            case R.id.dismiss:
                if (checked)
                    type = "Dismissed";
                break;
        }return type;
        }
    }


