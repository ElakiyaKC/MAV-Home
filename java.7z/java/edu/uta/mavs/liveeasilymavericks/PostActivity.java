package edu.uta.mavs.liveeasilymavericks;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TimePicker;
import android.widget.Toast;

import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Calendar;

public class PostActivity extends AppCompatActivity {
    Button logoutbtn, postbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post);

        final EditText eDate = (EditText)findViewById(R.id.eDate);

        eDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //To show current date in the datepicker
                Calendar mcurrentDate = Calendar.getInstance();
                int mYear = mcurrentDate.get(Calendar.YEAR);
                int mMonth = mcurrentDate.get(Calendar.MONTH);
                int mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker;
                mDatePicker = new DatePickerDialog(PostActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                        // TODO Auto-generated method stub
                        // Your code   to get date and time
                        selectedmonth = selectedmonth + 1;
                        eDate.setText("" + selectedday + "/" + selectedmonth + "/" + selectedyear);
                    }
                }, mYear, mMonth, mDay);
                mDatePicker.setTitle("Select Date");
                mDatePicker.show();
            }
        });


        final EditText eTime = (EditText)findViewById(R.id.eTime);

        eTime.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(PostActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        eTime.setText( selectedHour + ":" + selectedMinute);
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();
            }
        });

        final EditText description=(EditText) findViewById(R.id.description);
        postbtn= (Button) findViewById(R.id.post_btn);
        postbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(eDate.getText().toString().isEmpty() || eTime.getText().toString().isEmpty() || type.isEmpty() || description.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please fill all the details", Toast.LENGTH_SHORT).show();
                    return;
                }
                else
                {
                    MyTask mytask = new MyTask();
                    mytask.execute(new String[]{eDate.getText().toString(), eTime.getText().toString(),type,description.getText().toString() });
                    Toast.makeText(getApplicationContext(), "The activity has been posted", Toast.LENGTH_SHORT).show();
                    Intent newa = new Intent(PostActivity.this, ManagerHomeActivity.class);
                    startActivity(newa);
                }

            }
        });
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(PostActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});

    }

        String type="";

        public void onRadioButtonClicked(View view) {
            // Is the button now checked?
            boolean checked = ((RadioButton) view).isChecked();

            // Check which radio button was clicked
            switch(view.getId()) {
                case R.id.neighborhood:
                    if (checked)
                        type="Neighbourhood Event";
                        break;
                case R.id.maintenance:
                    if (checked)
                        type = "Maintenance Activity";
                        break;
            }
        };

private class MyTask extends AsyncTask<String, Void, Void> {
    private static final String url = "#####;
    private static final String username = "#####";
    private static final String password = "#####";
    @Override
    protected Void doInBackground(String... params) {
        try {
            final String dt =params[0];
            final String tm =params[1];
            final String typ =params[2];
            final String desc =params[3];

            Class.forName("com.mysql.jdbc.Driver");
            java.sql.Connection conn = DriverManager.getConnection(url,username,password);
			Statement st = conn.createStatement();
            String sql = "Insert into activity (date, time, type, description)"+ "values ('"+dt+"','"+tm+"','"+typ+"','"+desc+"')";
            //System.out.println(sql);
            st.executeUpdate(sql);





        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
}