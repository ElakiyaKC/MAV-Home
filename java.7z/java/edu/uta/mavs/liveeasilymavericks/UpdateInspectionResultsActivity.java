package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class UpdateInspectionResultsActivity extends AppCompatActivity {
    Button logoutbtn,updatebtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_inspection_results);
        updatebtn = (Button) findViewById(R.id.update_btn);
        updatebtn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Runnable r = new Runnable() {
                    @Override
                    public void run(){
                        Toast t=Toast.makeText(getApplicationContext(),"Inspection result has been updated", Toast.LENGTH_SHORT);
                        t.show();
                        Intent n4 = new Intent(UpdateInspectionResultsActivity.this, ManageInspectionActivity.class);
                        startActivity(n4);
                    }
                };
                Handler h = new Handler();
                h.postDelayed(r, 1000);
            }
        });



        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(UpdateInspectionResultsActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});
    }
}
