package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

public class ManagerHomeActivity extends AppCompatActivity {
    Button logoutbtn;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manager_home);
        logoutbtn = (Button) findViewById(R.id.logout_btn);




    //    ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.activity_manager_home);

        ListView list = (ListView) findViewById(R.id.manager_home_list);
    //    list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case 0:
                        Runnable r1 = new Runnable() {
                            @Override
                            public void run(){
                                Intent newActivity = new Intent(ManagerHomeActivity.this, ViewApartmentListActivity.class);
                                startActivity(newActivity);
                            }
                        };
                        Handler h1 = new Handler();
                        h1.postDelayed(r1, 1000);
                        break;
                    case 1:  Intent newActivity1 = new Intent(ManagerHomeActivity.this, PostActivity.class);
                        startActivity(newActivity1);
                        break;
                    /*case 1:  Toast toast1=Toast.makeText(getApplicationContext(),"The activity has been posted", Toast.LENGTH_LONG);
                        toast1.setGravity(Gravity.CENTER, 0, 0);
                        toast1.show();
                        break;*/
                    case 2:
                        Runnable r = new Runnable() {
                            @Override
                            public void run(){
                                Intent newActivity2 = new Intent(ManagerHomeActivity.this, ViewComplaintActivity.class);
                                startActivity(newActivity2);
                            }
                        };
                        Handler h = new Handler();
                        h.postDelayed(r, 1000);
                        break;
                }
            }
        });
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(ManagerHomeActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});

    }

}
