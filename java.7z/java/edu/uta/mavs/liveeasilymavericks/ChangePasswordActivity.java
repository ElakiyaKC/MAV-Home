package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ChangePasswordActivity extends AppCompatActivity {
    Button changebtn, logoutbtn;
    private static final String url =  "#######";  //(jdbc:mysql://localhost:port to which db is connected/dbname)
    private static final String username = "#####";
    private static final String password = "#####";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        final EditText oldpassword = (EditText) findViewById(R.id.editText);
        final EditText newpassword1 = (EditText) findViewById(R.id.editText2);
        final EditText newpassword2 = (EditText) findViewById(R.id.editText3);
        changebtn = (Button) findViewById(R.id.change_btn);

        changebtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MyTask k = new MyTask();
                k.execute(new String[]{oldpassword.getText().toString(), newpassword1.getText().toString(), newpassword2.getText().toString()});
            }
        });
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(ChangePasswordActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});
    }

    private class MyTask extends AsyncTask<String, Void, Void> {
        private static final String url =  "#####";
        private static final String username = "#####";
        private static final String password = "#####";
        @Override
        protected Void doInBackground(String... params) {
            try {
                final String oldpwd = params[0];
                final String newpwd1 = params[1];
                final String newpwd2= params[2];
                Class.forName("com.mysql.jdbc.Driver");
                java.sql.Connection conn = DriverManager.getConnection(url,username,password);//"jdbc:mysql://127.0.0.1:3306/mavericks","root","");//url, username, password);
                Statement st = conn.createStatement();
                String sql = "select * from users where password='"+oldpwd+"'";
                final ResultSet rs = st.executeQuery(sql);
                if(!rs.next()){
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run () {
                            Toast failure = Toast.makeText(getApplicationContext(), "The old password entered is incorrect", Toast.LENGTH_SHORT);
                            failure.show();
                        }
                    });
                }
                else
                {
                    String pwd=rs.getString("password");
                    if(newpwd1.equals(newpwd2)) {
                        String sql1 = "update users set password='"+newpwd1+"' where password='"+ oldpwd+"'";
                        st.executeUpdate(sql1);
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run () {
                                Toast success = Toast.makeText(getApplicationContext(), "The password has been changed", Toast.LENGTH_SHORT);
                                success.show();
                                Intent intent = new Intent(ChangePasswordActivity.this, TenantHomeActivity.class);
                                startActivity(intent);
                            }
                        });
                    }
                    else {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run () {
                                Toast mismatch = Toast.makeText(getApplicationContext(), "The passwords doesn't match", Toast.LENGTH_LONG);
                                mismatch.show();
                            }
                        });

                    }
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            /*Toast toast = Toast.makeText(getApplicationContext(),"login successful",Toast.LENGTH_SHORT);
            toast.show();*/

            super.onPostExecute(aVoid);
        }
    }

    public void changepassword(View view) {
        Toast toast=Toast.makeText(getApplicationContext(),"The password has been changed", Toast.LENGTH_LONG);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }

}
