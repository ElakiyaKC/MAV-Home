package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class TenantHomeActivity extends AppCompatActivity {
    Button logoutbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenant_home);

        ListView list = (ListView) findViewById(R.id.tenant_home_list);
        //    list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch (position) {
                    case 0:
                        Intent newActivity = new Intent(TenantHomeActivity.this, InitiateComplaintActivity.class);
                        startActivity(newActivity);
                        break;
                    case 1:
                        Runnable r1 = new Runnable() {
                            @Override
                            public void run(){
                                Toast toast0=Toast.makeText(getApplicationContext(),"The previous complaint has been resolved.", Toast.LENGTH_LONG);
                                toast0.setGravity(Gravity.CENTER, 0, 0);
                                toast0.show();
                            }
                        };
                        Handler h1 = new Handler();
                        h1.postDelayed(r1, 1000);
                        break;
                    case 2:
                        Runnable r2 = new Runnable() {
                            @Override
                            public void run(){
                                Intent newActivity1 = new Intent(TenantHomeActivity.this, ViewActivitiesActivity.class);
                                startActivity(newActivity1);
                            }
                        };
                        Handler h2 = new Handler();
                        h2.postDelayed(r2, 1000);
                        break;
                    case 3:
                        Intent newActivity2 = new Intent(TenantHomeActivity.this, PostMoveOutSalesActivity.class);
                        startActivity(newActivity2);
                        break;
                    case 4:
                        Runnable r = new Runnable() {
                            @Override
                            public void run(){
                                Toast toast3=Toast.makeText(getApplicationContext(),"You have passed your last inspection", Toast.LENGTH_LONG);
                                toast3.setGravity(Gravity.CENTER, 0, 0);
                                toast3.show();
                            }
                        };

                        Handler h = new Handler();
                        h.postDelayed(r, 1000);

                        break;
                    case 5:
                        Intent newActivity4 = new Intent(TenantHomeActivity.this, ChangePasswordActivity.class);
                        startActivity(newActivity4);
                        break;
                }
            }
        });
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(TenantHomeActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});

    }

}