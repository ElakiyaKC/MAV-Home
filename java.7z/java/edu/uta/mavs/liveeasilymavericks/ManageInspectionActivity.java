package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class ManageInspectionActivity extends AppCompatActivity {
    Button logoutbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manage_inspection);

        ListView list = (ListView) findViewById(R.id.manage_inspection_list);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    /*case 0:  Intent newActivity = new Intent(ManageInspectionActivity.this, ScheduleInspectionActivity.class);
                        startActivity(newActivity);
                        break;*/
                    case 0:  Intent newA2 = new Intent(ManageInspectionActivity.this, ScheduleInspectionActivity.class);
                        startActivity(newA2);


                        break;
                    case 1:
                        Runnable r = new Runnable() {
                            @Override
                            public void run(){
                                Toast toast1=Toast.makeText(getApplicationContext(),"The inpection has been deleted", Toast.LENGTH_LONG);
                                toast1.setGravity(Gravity.CENTER, 0, 0);
                                toast1.show();
                            }
                        };
                        Handler h = new Handler();
                        h.postDelayed(r, 1000);
                        break;
                    case 2:  Intent newActivity2 = new Intent(ManageInspectionActivity.this, UpdateInspectionResultsActivity.class);
                        startActivity(newActivity2);
                        break;
                    /*case 2:  Toast toast2=Toast.makeText(getApplicationContext(),"The result has been updated", Toast.LENGTH_LONG);
                        toast2.setGravity(Gravity.CENTER, 0, 0);
                        toast2.show();
                        break;*/
                }
            }
        });
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(ManageInspectionActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});
    }
}
