package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

public class ViewComplaintActivity2 extends AppCompatActivity {
    Button logoutbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_complaint2);

        ListView list = (ListView) findViewById(R.id.complaint_list2);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                switch(position){
                    case 0:  Intent newActivity = new Intent(ViewComplaintActivity2.this, ManageComplaintActivity.class);
                        startActivity(newActivity);
                        break;
                    case 1:  Toast toast1=Toast.makeText(getApplicationContext(),"The complaint has been updated", Toast.LENGTH_LONG);
                        toast1.setGravity(Gravity.CENTER, 0, 0);
                        toast1.show();
                        break;
                    case 2:  Intent newActivity2 = new Intent(ViewComplaintActivity2.this, ViewComplaintActivity.class);
                        startActivity(newActivity2);
                        break;
                }
            }
        });
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(ViewComplaintActivity2.this, LoginActivity.class);
                startActivity(newActivity);
            }});
    }
}
