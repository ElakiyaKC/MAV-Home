package edu.uta.mavs.liveeasilymavericks;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.DriverManager;
import java.sql.Statement;
import java.util.Calendar;

public class AddTenantActivity extends AppCompatActivity {

    private int mYear;
    private int mMonth;
    private int mDay;
    Button logoutbtn,mPickDate;

    //private TextView dob,ldate,tdate;
    private Button addbtn;

    static final int DATE_DIALOG_ID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_tenant);
        addbtn = (Button) findViewById(R.id.add_btn);

        final EditText firstname = (EditText) findViewById(R.id.fname);
        final EditText lastname = (EditText) findViewById(R.id.lname);

        final EditText apt = (EditText) findViewById(R.id.apt_num);
        final EditText mail = (EditText) findViewById(R.id.email);
        final EditText phoneno = (EditText) findViewById(R.id.phone);
        //final RadioGroup gender = (RadioGroup) findViewById(R.id.radioGroup2);
        final String gender="female";
     
        final EditText utaid = (EditText) findViewById(R.id.uta_id);
        final EditText uname = (EditText) findViewById(R.id.username);
        final EditText passwrd = (EditText) findViewById(R.id.password);



        // display the current date



        final EditText bDate = (EditText) findViewById(R.id.dob);

        bDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //To show current date in the datepicker
                Calendar mcurrentDate = Calendar.getInstance();
                int mYear = mcurrentDate.get(Calendar.YEAR);
                int mMonth = mcurrentDate.get(Calendar.MONTH);
                int mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker;
                mDatePicker = new DatePickerDialog(AddTenantActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                        // TODO Auto-generated method stub
                        // Your code   to get date and time
                        selectedmonth = selectedmonth + 1;
                        bDate.setText("" + selectedday + "/" + selectedmonth + "/" + selectedyear);
                    }
                }, mYear, mMonth, mDay);
                mDatePicker.setTitle("Select Date");
                mDatePicker.show();
            }
        });

        final EditText lDate = (EditText) findViewById(R.id.lDate);

        lDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //To show current date in the datepicker
                Calendar mcurrentDate = Calendar.getInstance();
                int mYear = mcurrentDate.get(Calendar.YEAR);
                int mMonth = mcurrentDate.get(Calendar.MONTH);
                int mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker;
                mDatePicker = new DatePickerDialog(AddTenantActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                        // TODO Auto-generated method stub
                        // Your code   to get date and time
                        selectedmonth = selectedmonth + 1;
                        lDate.setText("" + selectedday + "/" + selectedmonth + "/" + selectedyear);
                    }
                }, mYear, mMonth, mDay);
                mDatePicker.setTitle("Select Date");
                mDatePicker.show();
            }
        });

        final EditText tDate = (EditText) findViewById(R.id.tDate);

        tDate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                //To show current date in the datepicker
                Calendar mcurrentDate = Calendar.getInstance();
                int mYear = mcurrentDate.get(Calendar.YEAR);
                int mMonth = mcurrentDate.get(Calendar.MONTH);
                int mDay = mcurrentDate.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog mDatePicker;
                mDatePicker = new DatePickerDialog(AddTenantActivity.this, new DatePickerDialog.OnDateSetListener() {
                    public void onDateSet(DatePicker datepicker, int selectedyear, int selectedmonth, int selectedday) {
                        // TODO Auto-generated method stub
                        // Your code   to get date and time
                        selectedmonth = selectedmonth + 1;
                        tDate.setText("" + selectedday + "/" + selectedmonth + "/" + selectedyear);
                    }
                }, mYear, mMonth, mDay);
                mDatePicker.setTitle("Select Date");
                mDatePicker.show();
            }
        });

        // display the current date


        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(AddTenantActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});


                addbtn = (Button) findViewById(R.id.add_btn);
        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(firstname.getText().toString().isEmpty() || lastname.getText().toString().isEmpty() || apt.getText().toString().isEmpty() || mail.getText().toString().isEmpty() ||phoneno.getText().toString().isEmpty()||utaid.getText().toString().isEmpty()||uname.getText().toString().isEmpty()|| passwrd.getText().toString().isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please fill all the details", Toast.LENGTH_SHORT).show();
                    return;
                }
                   else
                {
                    MyTask mytask = new MyTask();
                    mytask.execute(new String[]{firstname.getText().toString(), lastname.getText().toString(), bDate.getText().toString(), apt.getText().toString(), mail.getText().toString(), phoneno.getText().toString(),gender,utaid.getText().toString(), uname.getText().toString(), passwrd.getText().toString(),lDate.getText().toString(),tDate.getText().toString()});
                    Toast.makeText(getApplicationContext(), "The tenant has been added", Toast.LENGTH_SHORT).show();
                    Intent newa = new Intent(AddTenantActivity.this, ManageTenantActivity.class);
                    startActivity(newa);
                }
            }

        });



    }

    private class MyTask extends AsyncTask<String, Void, Void> {
        private static final String url = "###########";
        private static final String username = "######";
        private static final String password = "#####";
        @Override
        protected Void doInBackground(String... params) {
            try {
                final String fname= params[0];
                final String lname = params[1];
                final String dob=params[2];
                final String apt=params[3];
                final String mail=params[4];
                final String phoneno=params[5];
                final String gender=params[6];
                final String utaid=params[7];
                final String uname=params[8];
                final String passwrd=params[9];
                final String leasedate=params[10];
                final String terminatedate=params[11];
                Class.forName("com.mysql.jdbc.Driver");
                java.sql.Connection conn = DriverManager.getConnection(url,username,password);
                Statement st = conn.createStatement();
                String sql = "Insert into tenant (firstname, lastname, dob, aptnumber, mailid, mobilenumber, gender, utaid, username, password, leasingdate, terminationdate)"+ "values ('"+fname+"','"+lname+"','"+dob+"','"+apt+"','"+mail+"','"+phoneno+"','"+gender+"','"+utaid+"','"+uname+"','"+passwrd+"','"+leasedate+"','"+terminatedate+"')";
                st.executeUpdate(sql);
                /*if(rs.next())
                {
                    Toast toast = Toast.makeText(getApplicationContext(),"The tenant has been added",Toast.LENGTH_SHORT);
                    toast.show();
                }

                else
                {
                    Toast toast = Toast.makeText(getApplicationContext(),"Please enter the correct data",Toast.LENGTH_SHORT);
                    toast.show();
                }*/
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

    }
}
