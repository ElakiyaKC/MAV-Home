package edu.uta.mavs.liveeasilymavericks;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.sql.DriverManager;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class InitiateComplaintActivity extends AppCompatActivity {
    private static final String url = "#####";
    private static final String username = "#####";
    private static final String password = "#####";
    Button logoutbtn;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_initiate_complaint);
        logoutbtn = (Button) findViewById(R.id.logout_btn);
        logoutbtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent newActivity = new Intent(InitiateComplaintActivity.this, LoginActivity.class);
                startActivity(newActivity);
            }});
        final EditText complaint = (EditText) findViewById(R.id.complaint);
        submit = (Button) findViewById(R.id.submit_btn);
        submit.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                MyTask mytask = new MyTask();
                mytask.execute(new String[]{complaint.getText().toString()});

            }

        });
    }
    private class MyTask extends AsyncTask<String, Void, Void> {
        private static final String url = "#####";
        private static final String username = "#####";
        private static final String password = "#####";

        @Override
        protected Void doInBackground(String... params) {
            try {
                final String complaint = params[0];
                String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

                Class.forName("com.mysql.jdbc.Driver");
                java.sql.Connection conn = DriverManager.getConnection(url, username, password);
                Statement st = conn.createStatement();

                String sql = "insert into complaint (date,time,postedby,description,actiontaken)"+"values ('"+date+"','09:00','NULL','"+complaint+"','NULL')";
                //System.out.println(sql);
                st.executeUpdate(sql);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run () {
                        Toast toast = Toast.makeText(getApplicationContext(), "The Complaint has been initiated", Toast.LENGTH_SHORT);
                        toast.show();
                        Intent intent = new Intent(InitiateComplaintActivity.this, TenantHomeActivity.class);
                        startActivity(intent);
                    }
                });


            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);
        }
    }

}
